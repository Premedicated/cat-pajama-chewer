# Fee Guide to CSV Converter - Improved Version

This package contains the improved Fee Guide to CSV Conversion Tool web application with enhanced extraction capabilities for multiple fee guide formats.

## Key Improvements

1. **Multi-Format Support**: Specialized extractors for different fee guide formats:
   - HealthPartners
   - Delta Dental
   - And more, with automatic format detection

2. **Better Structure Preservation**: Uses PDF.js for improved PDF extraction that maintains document structure

3. **Intelligent Extraction**: Enhanced algorithms to accurately identify ADA codes and their corresponding prices

4. **Fallback Mechanisms**: Multiple extraction strategies with fallbacks for maximum coverage

5. **Detailed Feedback**: Shows extraction details and format detection information

## Installation

### Prerequisites
- Node.js 16+ and npm/pnpm installed

### Steps
1. Extract this package to a folder
2. Open a terminal in that folder
3. Install dependencies:
   ```
   npm install
   ```
   or
   ```
   pnpm install
   ```

## Running the Application

### Development Mode
```
npm run dev
```
or
```
pnpm run dev
```

Access the application at http://localhost:3000

### Production Mode
```
npm run build
npm start
```
or
```
pnpm run build
pnpm start
```

## Deployment Options

### Option 1: Deploy to Netlify

1. **Sign up for Netlify**:
   - Go to [netlify.com](https://www.netlify.com/) and create a free account

2. **Deploy the application**:
   - From your Netlify dashboard, click "Add new site" → "Import an existing project"
   - Connect to your Git provider or upload the files directly
   - Netlify will automatically detect Next.js and configure the build settings
   - Click "Deploy"

### Option 2: Deploy to Vercel

1. **Sign up for Vercel**:
   - Go to [vercel.com](https://vercel.com/) and create a free account
   - Connect your GitHub, GitLab, or Bitbucket account

2. **Deploy the application**:
   - Click "New Project"
   - Import this repository from your Git provider or upload the files
   - Vercel will automatically detect Next.js and configure the build settings
   - Click "Deploy"

### Option 3: Self-Host on Your Own Server

1. **Prerequisites**:
   - A web server (Apache, Nginx, etc.)
   - Node.js 16+ and npm/pnpm installed

2. **Installation steps**:
   - Upload all files to your server
   - Run `npm install` or `pnpm install` to install dependencies
   - Run `npm run build` or `pnpm run build` to build the application
   - Set up a process manager like PM2: `npm install -g pm2`
   - Start the application: `pm2 start npm -- start`

3. **Server configuration**:
   - Configure your web server to proxy requests to the Node.js server (port 3000 by default)

## Using the Application

1. **Upload a Fee Guide**:
   - Drag and drop a PDF or Excel file containing dental fee guide information
   - The application will automatically detect the format and apply the appropriate extraction strategy

2. **Review Results**:
   - The application will display the extracted ADA codes and prices
   - You'll see how many items were extracted and details about the extraction process

3. **Download CSV**:
   - Click the "Download CSV" button to get a standardized CSV file with adaCode and price columns
   - The CSV can be imported into other systems or opened in Excel

## Troubleshooting

### Extraction Issues

If the application doesn't extract all codes or prices correctly:

1. **Try a different file format**: If you have both PDF and Excel versions, try both to see which works better
2. **Check file quality**: Make sure the PDF is not scanned or image-based; text-based PDFs work best
3. **Contact support**: Provide the file for analysis so we can enhance the extraction for your specific format

### Technical Issues

- **Build errors**: Make sure you have Node.js 16+ installed
- **Runtime errors**: Check the browser console for JavaScript errors
- **API errors**: Verify that all dependencies are installed correctly

## Customization

The application can be customized to handle additional fee guide formats:

1. Add new format detection in `detectFeeGuideFormat()` in pdf-extractor.ts
2. Create a specialized extractor function for the new format
3. Add the new extractor to the switch statement in the main extraction function

## License

This application is provided for your personal or business use. Redistribution is not permitted without explicit permission.
