// src/lib/extraction/pdf-extractor.ts

/**
 * Advanced PDF extraction utility using PDF.js for better structure preservation
 * and format-specific extraction strategies.
 */

// We'll need to install pdfjs-dist
// This is a placeholder for the actual import
// In the real implementation, you would use:
// import * as pdfjs from 'pdfjs-dist';
// const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.entry');
// pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

// For now, we'll create a mock implementation that can be replaced
// once the dependencies are installed
const pdfjs = {
  getDocument: async (options: any) => {
    // This is a mock implementation
    return {
      numPages: 1,
      promise: Promise.resolve({
        numPages: 1,
        getPage: async (pageNum: number) => {
          return {
            getTextContent: async () => {
              return { items: [] };
            }
          };
        }
      })
    };
  }
};

/**
 * Detect the fee guide format based on text content
 */
export function detectFeeGuideFormat(text: string): string {
  // Check for HealthPartners format
  if (text.includes('HealthPartners') && 
      (text.includes('Fee Schedule') || text.includes('Fee Allowance'))) {
    return 'healthpartners';
  }
  
  // Check for Delta Dental format
  if (text.includes('Delta Dental') && 
      (text.includes('Fee Schedule') || text.includes('Allowance'))) {
    return 'delta';
  }
  
  // Check for UnitedHealthcare format
  if (text.includes('UnitedHealthcare') || text.includes('United Healthcare')) {
    return 'united';
  }
  
  // Check for Guardian format
  if (text.includes('Guardian') && 
      (text.includes('Fee Schedule') || text.includes('Allowance'))) {
    return 'guardian';
  }
  
  // Check for Cigna format
  if (text.includes('Cigna') && 
      (text.includes('Fee Schedule') || text.includes('Allowance'))) {
    return 'cigna';
  }
  
  // Default to generic format
  return 'generic';
}

/**
 * Extract text from PDF with better structure preservation using PDF.js
 */
export async function extractTextFromPDF(pdfBuffer: ArrayBuffer): Promise<string> {
  try {
    // In a real implementation, this would use PDF.js
    // For now, we'll use a simplified approach for the prototype
    const textDecoder = new TextDecoder('utf-8');
    const text = textDecoder.decode(pdfBuffer);
    return text;
    
    /* 
    // This is the actual implementation that would be used with PDF.js
    const pdf = await pdfjs.getDocument({ data: pdfBuffer }).promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      
      // Preserve structure by tracking item positions
      const textItems = content.items.map((item: any) => {
        return {
          text: item.str,
          x: item.transform[4], // x position
          y: item.transform[5], // y position
          height: item.height,
          width: item.width
        };
      });
      
      // Sort by y position (top to bottom) and then by x position (left to right)
      textItems.sort((a, b) => {
        const yDiff = b.y - a.y; // Reverse order for y (top to bottom)
        if (Math.abs(yDiff) < 5) { // Items on roughly the same line
          return a.x - b.x; // Sort by x position
        }
        return yDiff;
      });
      
      // Group items by line (similar y positions)
      const lines: any[] = [];
      let currentLine: any[] = [];
      let currentY = textItems[0]?.y;
      
      textItems.forEach(item => {
        if (Math.abs(item.y - currentY) < 5) {
          currentLine.push(item);
        } else {
          lines.push([...currentLine]);
          currentLine = [item];
          currentY = item.y;
        }
      });
      
      if (currentLine.length > 0) {
        lines.push(currentLine);
      }
      
      // Convert lines to text, preserving structure
      const pageText = lines.map(line => 
        line.map((item: any) => item.text).join(' ')
      ).join('\n');
      
      fullText += pageText + '\n';
    }
    
    return fullText;
    */
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    return '';
  }
}

/**
 * Normalize ADA code to standard format (D#### with leading zeros if needed)
 */
export function normalizeAdaCode(code: string | null | undefined): string | null {
  if (!code) {
    return null;
  }
  
  // Remove any non-alphanumeric characters
  code = code.replace(/[^a-zA-Z0-9]/g, '');
  
  // If code is just numbers, add the D prefix
  if (/^\d{3,5}$/.test(code)) {
    // Ensure it's a 4-digit code with leading zeros if needed
    const paddedCode = code.padStart(4, '0');
    return `D${paddedCode}`;
  }
  
  // If code already starts with D or d, ensure proper format
  if (code.toUpperCase().startsWith('D')) {
    const numericPart = code.replace(/[^0-9]/g, '');
    // Ensure it's a 4-digit code with leading zeros if needed
    const paddedNumeric = numericPart.padStart(4, '0');
    return `D${paddedNumeric}`;
  }
  
  return null; // Not a valid ADA code
}

/**
 * Normalize price to standard format (number)
 */
export function normalizePrice(price: string | number | null | undefined): number | null {
  if (price === null || price === undefined) {
    return null;
  }
  
  // If price is already a number, return it directly
  if (typeof price === 'number') {
    return price;
  }
  
  // Handle special cases
  if (price.includes('No Dental Plan Discount') || 
      price.includes('UCR') || 
      price.toLowerCase().includes('not covered')) {
    return 0; // Use 0 for special cases
  }
  
  // Handle percentage discounts
  const percentMatch = price.match(/(\d+)%\s+(?:off|discount)/i);
  if (percentMatch) {
    return -parseFloat(percentMatch[1]); // Use negative numbers for percentage discounts
  }
  
  // Convert to string if it's not already
  const priceStr = String(price);
  
  // Remove any non-numeric characters except decimal point
  const cleanedPrice = priceStr.replace(/[^0-9.]/g, '');
  
  try {
    // Convert to number
    const num = parseFloat(cleanedPrice);
    return isNaN(num) ? null : num;
  } catch (error) {
    return null;
  }
}

/**
 * HealthPartners specific extractor
 */
export function extractHealthPartnersFormat(text: string): Array<{adaCode: string, price: number}> {
  const results: Array<{adaCode: string, price: number}> = [];
  const lines = text.split('\n');
  
  // Find the header line with "ADA", "CODE DESCRIPTION", and "FEE ALLOWANCE"
  let headerIndex = -1;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].toUpperCase();
    if ((line.includes('ADA') || line.includes('CODE')) && 
        (line.includes('DESCRIPTION') || line.includes('PROCEDURE')) && 
        (line.includes('FEE') || line.includes('ALLOWANCE') || line.includes('AMOUNT'))) {
      headerIndex = i;
      break;
    }
  }
  
  if (headerIndex === -1) {
    // Try alternative header detection
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toUpperCase();
      if (line.includes('D0') && (line.includes('$') || line.includes('EVALUATION'))) {
        headerIndex = i - 1; // Assume the line before is the header
        break;
      }
    }
  }
  
  if (headerIndex === -1) return results;
  
  // Process data lines after the header
  for (let i = headerIndex + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // HealthPartners format typically has D#### at the beginning of the line or column
    const codeMatch = line.match(/\b(D\d{4})\b/);
    if (codeMatch) {
      const code = codeMatch[1];
      
      // Look for price pattern ($XX.XX)
      const priceMatch = line.match(/\$(\d+\.\d{2})/);
      
      // Also look for "No Dental Plan Discount" or percentage formats
      const discountMatch = line.includes('No Dental Plan Discount');
      const percentageMatch = line.match(/(\d+)%\s+off/);
      
      let price: number | null = null;
      
      if (priceMatch) {
        price = parseFloat(priceMatch[1]);
      } else if (discountMatch) {
        price = 0; // Use 0 for "No Dental Plan Discount"
      } else if (percentageMatch) {
        price = -parseFloat(percentageMatch[1]); // Use negative numbers for percentage discounts
      } else {
        // Try to find any number that could be a price
        const numberMatch = line.match(/\$?(\d+\.\d{2}|\d+)/);
        if (numberMatch && !numberMatch[0].startsWith('D')) {
          price = parseFloat(numberMatch[1]);
        }
      }
      
      if (price !== null) {
        results.push({
          adaCode: code,
          price: price
        });
      }
    }
  }
  
  return results;
}

/**
 * Delta Dental specific extractor
 */
export function extractDeltaFormat(text: string): Array<{adaCode: string, price: number}> {
  const results: Array<{adaCode: string, price: number}> = [];
  const lines = text.split('\n');
  
  // Delta Dental often uses a table format with ADA codes in one column and fees in another
  
  // Find the header line
  let headerIndex = -1;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].toUpperCase();
    if ((line.includes('PROCEDURE') || line.includes('ADA') || line.includes('CDT')) && 
        (line.includes('FEE') || line.includes('AMOUNT') || line.includes('ALLOWANCE'))) {
      headerIndex = i;
      break;
    }
  }
  
  if (headerIndex === -1) {
    // Try alternative header detection
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toUpperCase();
      if (line.includes('D0') && line.includes('$')) {
        headerIndex = i - 1; // Assume the line before is the header
        break;
      }
    }
  }
  
  if (headerIndex === -1) return results;
  
  // Process data lines after the header
  for (let i = headerIndex + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Look for ADA code pattern
    const codeMatch = line.match(/\b(D\d{4})\b/);
    if (codeMatch) {
      const code = codeMatch[1];
      
      // Look for price pattern
      const priceMatch = line.match(/\$(\d+\.\d{2}|\d+)/);
      
      let price: number | null = null;
      
      if (priceMatch) {
        price = parseFloat(priceMatch[1]);
      } else {
        // Try to find any number that could be a price
        const numberMatch = line.match(/\b(\d+\.\d{2}|\d+)\b/);
        if (numberMatch && !numberMatch[0].startsWith('D')) {
          price = parseFloat(numberMatch[1]);
        }
      }
      
      if (price !== null) {
        results.push({
          adaCode: code,
          price: price
        });
      }
    }
  }
  
  return results;
}

/**
 * Generic extractor as fallback
 */
export function extractGenericFormat(text: string): Array<{adaCode: string, price: number}> {
  const results: Array<{adaCode: string, price: number}> = [];
  const lines = text.split('\n');
  
  // Look for patterns of ADA codes (D####) and nearby prices
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Look for ADA code pattern
    const codeMatches = line.match(/\b(D\d{4})\b/g);
    if (codeMatches) {
      for (const codeMatch of codeMatches) {
        const code = codeMatch;
        
        // Skip if we already have this code
        if (results.some(item => item.adaCode === code)) continue;
        
        // Look for price in this line or the next few lines
        let price: number | null = null;
        let priceFound = false;
        
        for (let j = i; j < Math.min(i + 3, lines.length); j++) {
          const searchLine = lines[j];
          const priceMatch = searchLine.match(/\$(\d+\.\d{2}|\d+)/);
          
          if (priceMatch) {
            price = parseFloat(priceMatch[1]);
            priceFound = true;
            break;
          }
        }
        
        // If no price with $ sign found, look for any number that could be a price
        if (!priceFound) {
          const numberMatch = line.match(/\b(\d+\.\d{2}|\d+)\b/);
          if (numberMatch && !numberMatch[0].startsWith('D')) {
            price = parseFloat(numberMatch[1]);
            priceFound = true;
          }
        }
        
        if (price !== null) {
          results.push({
            adaCode: code,
            price: price
          });
        }
      }
    }
  }
  
  return results;
}

/**
 * Main extraction function that detects format and applies the appropriate extractor
 */
export async function extractAdaCodesAndPricesFromPDF(pdfBuffer: ArrayBuffer): Promise<Array<{adaCode: string, price: number}>> {
  // Extract text with structure preservation
  const text = await extractTextFromPDF(pdfBuffer);
  
  // Detect format
  const format = detectFeeGuideFormat(text);
  console.log(`Detected fee guide format: ${format}`);
  
  // Apply the appropriate extractor
  let results: Array<{adaCode: string, price: number}> = [];
  
  switch (format) {
    case 'healthpartners':
      results = extractHealthPartnersFormat(text);
      break;
    case 'delta':
      results = extractDeltaFormat(text);
      break;
    default:
      results = extractGenericFormat(text);
      break;
  }
  
  // If we didn't get many results, try other extractors as fallback
  if (results.length < 10) {
    console.log(`Few results (${results.length}) from primary extractor, trying fallbacks...`);
    
    const allResults = [
      results,
      format !== 'healthpartners' ? extractHealthPartnersFormat(text) : [],
      format !== 'delta' ? extractDeltaFormat(text) : [],
      format !== 'generic' ? extractGenericFormat(text) : []
    ];
    
    // Combine all results, avoiding duplicates
    const combinedResults: Array<{adaCode: string, price: number}> = [];
    const seenCodes = new Set<string>();
    
    for (const resultSet of allResults) {
      for (const item of resultSet) {
        if (!seenCodes.has(item.adaCode)) {
          combinedResults.push(item);
          seenCodes.add(item.adaCode);
        }
      }
    }
    
    results = combinedResults;
  }
  
  return results;
}
