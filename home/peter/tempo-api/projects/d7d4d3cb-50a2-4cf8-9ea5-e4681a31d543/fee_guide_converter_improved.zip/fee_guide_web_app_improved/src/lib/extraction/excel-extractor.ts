// src/lib/extraction/excel-extractor.ts

/**
 * Advanced Excel extraction utility for fee guides
 */

import * as XLSX from 'xlsx';
import { normalizeAdaCode, normalizePrice } from './pdf-extractor';

/**
 * Detect the fee guide format based on Excel content
 */
export function detectExcelFeeGuideFormat(workbook: XLSX.WorkBook): string {
  // Check all sheets for format indicators
  for (const sheetName of workbook.SheetNames) {
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    
    // Convert to string for easier searching
    const textContent = JSON.stringify(jsonData).toLowerCase();
    
    // Check for HealthPartners format
    if (textContent.includes('healthpartners') && 
        (textContent.includes('fee schedule') || textContent.includes('fee allowance'))) {
      return 'healthpartners';
    }
    
    // Check for Delta Dental format
    if (textContent.includes('delta dental') && 
        (textContent.includes('fee schedule') || textContent.includes('allowance'))) {
      return 'delta';
    }
    
    // Check for UnitedHealthcare format
    if (textContent.includes('unitedhealthcare') || textContent.includes('united healthcare')) {
      return 'united';
    }
    
    // Check for Guardian format
    if (textContent.includes('guardian') && 
        (textContent.includes('fee schedule') || textContent.includes('allowance'))) {
      return 'guardian';
    }
    
    // Check for Cigna format
    if (textContent.includes('cigna') && 
        (textContent.includes('fee schedule') || textContent.includes('allowance'))) {
      return 'cigna';
    }
  }
  
  // Default to generic format
  return 'generic';
}

/**
 * Find column indices for ADA codes and prices
 */
function findColumnIndices(headers: any[]): { codeIndex: number, priceIndex: number } {
  let codeIndex = -1;
  let priceIndex = -1;
  
  // Convert headers to strings and lowercase for easier matching
  const headerStrings = headers.map(h => String(h || '').toLowerCase());
  
  // Keywords to look for in headers
  const codeKeywords = ['code', 'ada', 'procedure', 'cdt', 'service'];
  const priceKeywords = ['fee', 'price', 'allowance', 'rate', 'amount', 'cost', 'charge'];
  
  // Find code column
  for (let i = 0; i < headerStrings.length; i++) {
    const header = headerStrings[i];
    if (codeKeywords.some(keyword => header.includes(keyword))) {
      codeIndex = i;
      break;
    }
  }
  
  // Find price column
  for (let i = 0; i < headerStrings.length; i++) {
    const header = headerStrings[i];
    if (priceKeywords.some(keyword => header.includes(keyword))) {
      priceIndex = i;
      break;
    }
  }
  
  // If we couldn't find by keywords, look for patterns in the data
  if (codeIndex === -1 || priceIndex === -1) {
    // This would be implemented based on data patterns
  }
  
  return { codeIndex, priceIndex };
}

/**
 * Extract ADA codes and prices from Excel data
 */
function extractFromExcelData(data: any[][]): Array<{adaCode: string, price: number}> {
  const results: Array<{adaCode: string, price: number}> = [];
  
  // Skip if no data
  if (!data || data.length < 2) return results;
  
  // Assume first row is headers
  const headers = data[0];
  const { codeIndex, priceIndex } = findColumnIndices(headers);
  
  // If we couldn't find the columns, try a different approach
  if (codeIndex === -1 || priceIndex === -1) {
    // Scan all cells for ADA code patterns
    for (let rowIndex = 0; rowIndex < data.length; rowIndex++) {
      const row = data[rowIndex];
      
      for (let colIndex = 0; colIndex < row.length; colIndex++) {
        const cell = String(row[colIndex] || '');
        
        // Check if cell contains an ADA code
        if (/\b[dD]?\d{4}\b/.test(cell)) {
          const normalizedCode = normalizeAdaCode(cell);
          if (!normalizedCode) continue;
          
          // Look for a price in the same row
          let price: number | null = null;
          
          for (let priceColIndex = 0; priceColIndex < row.length; priceColIndex++) {
            if (priceColIndex === colIndex) continue; // Skip the code cell
            
            const priceCell = row[priceColIndex];
            if (priceCell !== undefined && priceCell !== null) {
              const normalizedPrice = normalizePrice(String(priceCell));
              if (normalizedPrice !== null) {
                price = normalizedPrice;
                break;
              }
            }
          }
          
          if (price !== null) {
            // Check if this code is already in results (avoid duplicates)
            if (!results.some(item => item.adaCode === normalizedCode)) {
              results.push({
                adaCode: normalizedCode,
                price: price
              });
            }
          }
        }
      }
    }
    
    return results;
  }
  
  // Process data rows
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (!row || row.length <= Math.max(codeIndex, priceIndex)) continue;
    
    const codeCell = row[codeIndex];
    const priceCell = row[priceIndex];
    
    if (!codeCell) continue;
    
    const normalizedCode = normalizeAdaCode(String(codeCell));
    if (!normalizedCode) continue;
    
    const normalizedPrice = normalizePrice(String(priceCell));
    if (normalizedPrice === null) continue;
    
    // Check if this code is already in results (avoid duplicates)
    if (!results.some(item => item.adaCode === normalizedCode)) {
      results.push({
        adaCode: normalizedCode,
        price: normalizedPrice
      });
    }
  }
  
  return results;
}

/**
 * Main function to extract ADA codes and prices from Excel file
 */
export function extractAdaCodesAndPricesFromExcel(buffer: ArrayBuffer): Array<{adaCode: string, price: number}> {
  try {
    // Parse the Excel file
    const workbook = XLSX.read(buffer, { type: 'array' });
    
    // Detect format
    const format = detectExcelFeeGuideFormat(workbook);
    console.log(`Detected Excel fee guide format: ${format}`);
    
    // Process all sheets and combine results
    const results: Array<{adaCode: string, price: number}> = [];
    const seenCodes = new Set<string>();
    
    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      
      // Extract from this sheet
      const sheetResults = extractFromExcelData(jsonData as any[][]);
      
      // Add to combined results, avoiding duplicates
      for (const item of sheetResults) {
        if (!seenCodes.has(item.adaCode)) {
          results.push(item);
          seenCodes.add(item.adaCode);
        }
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error extracting data from Excel:', error);
    return [];
  }
}
