'use client';

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

export default function FileUploader() {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [extractionDetails, setExtractionDetails] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    setResult(null);
    setExtractionDetails(null);
    
    const selectedFile = acceptedFiles[0];
    
    // Check if file is PDF or Excel
    const fileType = selectedFile.type;
    const isPdf = fileType === 'application/pdf';
    const isExcel = 
      fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
      fileType === 'application/vnd.ms-excel';
    
    if (!isPdf && !isExcel) {
      setError('Please upload a PDF or Excel file only.');
      return;
    }
    
    setFile(selectedFile);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: false
  });

  const handleUpload = async () => {
    if (!file) return;
    
    setIsProcessing(true);
    setError(null);
    setResult(null);
    setExtractionDetails(null);
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const response = await fetch('/api/convert', {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Error processing file');
      }
      
      setResult(data);
      
      // Set extraction details
      const fileType = file.type.includes('pdf') ? 'PDF' : 'Excel';
      setExtractionDetails(`Successfully extracted from ${fileType} file. Format detected automatically.`);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error processing file. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    
    // Create CSV content
    const csvContent = 'adaCode,price\n' + 
      result.data.map((item: {adaCode: string, price: number}) => `${item.adaCode},${item.price}`).join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'fee_guide.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-xl mx-auto p-6">
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
        }`}
      >
        <input {...getInputProps()} />
        <svg 
          className="mx-auto h-12 w-12 text-gray-400" 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24" 
          xmlns="http://www.w3.org/2000/svg"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
          />
        </svg>
        
        {file ? (
          <p className="mt-2 text-sm text-gray-700">
            Selected file: <span className="font-medium">{file.name}</span>
          </p>
        ) : (
          <>
            <p className="mt-2 text-sm font-medium text-gray-900">
              Drag and drop your fee guide file here
            </p>
            <p className="mt-1 text-xs text-gray-500">
              Supports PDF and Excel (.xlsx) files
            </p>
          </>
        )}
      </div>
      
      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}
      
      {file && !isProcessing && !result && (
        <button
          onClick={handleUpload}
          className="mt-4 w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Convert to CSV
        </button>
      )}
      
      {isProcessing && (
        <div className="mt-4 text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div>
          <p className="mt-2 text-sm text-gray-700">Processing your file...</p>
        </div>
      )}
      
      {result && (
        <div className="mt-6">
          <div className="bg-green-50 p-4 rounded-md">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-800">Conversion successful!</h3>
                <p className="mt-2 text-sm text-green-700">
                  {result.data.length} ADA codes and prices extracted.
                </p>
                {extractionDetails && (
                  <p className="mt-1 text-xs text-green-600">
                    {extractionDetails}
                  </p>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-md">
            <ul className="divide-y divide-gray-200">
              {result.data.slice(0, 5).map((item: {adaCode: string, price: number}, index: number) => (
                <li key={index} className="px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-gray-900">{item.adaCode}</div>
                    <div className="text-sm text-gray-500">${item.price}</div>
                  </div>
                </li>
              ))}
            </ul>
            {result.data.length > 5 && (
              <div className="px-4 py-3 bg-gray-50 text-sm text-gray-500 text-center">
                And {result.data.length - 5} more items...
              </div>
            )}
          </div>
          
          <button
            onClick={handleDownload}
            className="mt-4 w-full py-2 px-4 bg-green-600 hover:bg-green-700 text-white font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
          >
            Download CSV
          </button>
          
          <button
            onClick={() => {
              setFile(null);
              setResult(null);
              setExtractionDetails(null);
            }}
            className="mt-2 w-full py-2 px-4 bg-white border border-gray-300 text-gray-700 font-medium rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Convert Another File
          </button>
        </div>
      )}
    </div>
  );
}
