// src/app/api/convert/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { extractAdaCodesAndPricesFromPDF } from '@/lib/extraction/pdf-extractor';
import { extractAdaCodesAndPricesFromExcel } from '@/lib/extraction/excel-extractor';

export async function POST(request: NextRequest) {
  try {
    // Get the form data from the request
    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }
    
    // Check file type
    const fileType = file.type;
    const isPdf = fileType === 'application/pdf';
    const isExcel = 
      fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
      fileType === 'application/vnd.ms-excel';
    
    if (!isPdf && !isExcel) {
      return NextResponse.json(
        { error: 'Unsupported file format. Please upload a PDF or Excel file.' },
        { status: 400 }
      );
    }
    
    // Convert file to buffer
    const buffer = await file.arrayBuffer();
    
    // Extract data based on file type
    let results: Array<{adaCode: string, price: number}> = [];
    
    if (isPdf) {
      console.log('Processing PDF file...');
      results = await extractAdaCodesAndPricesFromPDF(buffer);
    } else if (isExcel) {
      console.log('Processing Excel file...');
      results = extractAdaCodesAndPricesFromExcel(buffer);
    }
    
    if (results.length === 0) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Could not extract ADA codes and prices from the file',
          count: 0
        },
        { status: 400 }
      );
    }
    
    // Return the results
    return NextResponse.json({
      success: true,
      data: results,
      count: results.length
    });
    
  } catch (error) {
    console.error('Error processing file:', error);
    return NextResponse.json(
      { error: 'Error processing file' },
      { status: 500 }
    );
  }
}
