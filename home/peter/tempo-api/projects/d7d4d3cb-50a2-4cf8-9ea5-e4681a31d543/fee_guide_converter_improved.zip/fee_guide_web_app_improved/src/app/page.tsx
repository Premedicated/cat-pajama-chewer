import FileUploader from '@/components/FileUploader';

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Fee Guide to CSV Converter
          </h1>
          <p className="mt-3 text-xl text-gray-500">
            Convert dental fee guides from PDF or Excel to standardized CSV format
          </p>
          <p className="mt-2 text-sm text-blue-600">
            Enhanced with multi-format extraction for HealthPartners, Delta Dental, and more
          </p>
        </div>
        
        <div className="bg-white shadow-lg rounded-lg overflow-hidden">
          <div className="p-6">
            <FileUploader />
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Supports PDF and Excel (.xlsx) files</p>
          <p className="mt-1">Automatically formats ADA codes and prices</p>
          <p className="mt-1">Detects and handles multiple fee guide formats</p>
        </div>
      </div>
    </main>
  );
}
